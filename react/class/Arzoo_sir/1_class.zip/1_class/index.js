const express = require('express')
const app = express()
const port = 3000

app.get('/', (req, res) => res.send('Hello World!'))
app.get("/name", (req, res) => res.send("Welcome sky"));
// app.get("/student",(req,res) => res.send("Dharmraj sodha\n sem 5th \nrku"))
// app.get("/student", (req, res) =>{ res.sendFile(Path.join(__dirname, "student.html"))})
app.get("/student",(req,res) => res.json({name:"dharmraj" , age:20,branch:"CE"}) )
app.listen(port, () => console.log(`Example app listening on port ${port}!`))


app.get('/user/:fname/:lname',(req,res)=> {
    var fname = req.params.fname
    var lname = req.params.lname
    res.send("hello "+fname+" "+lname)
})

app.post("/hel",(req,res) => res.send("hoo00000"))